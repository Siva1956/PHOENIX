<!DOCTYPE html>
<html>
<head>
    <title>Quiz</title>
</head>
<body>
    <h1>Quiz</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <p>1. What is the capital of France?</p>
        <input type="radio" name="q1" value="a"> a) Paris<br>
        <input type="radio" name="q1" value="b"> b) Rome<br>
        <input type="radio" name="q1" value="c"> c) London<br>
        <input type="radio" name="q1" value="d"> d) Berlin<br>

        <p>2. What is the largest planet in our solar system?</p>
        <input type="radio" name="q2" value="a"> a) Earth<br>
        <input type="radio" name="q2" value="b"> b) Mars<br>
        <input type="radio" name="q2" value="c"> c) Jupiter<br>
        <input type="radio" name="q2" value="d"> d) Saturn<br>

        <p>3. What is the capital of Japan?</p>
        <input type="radio" name="q3" value="a"> a) Tokyo<br>
        <input type="radio" name="q3" value="b"> b) Beijing<br>
        <input type="radio" name="q3" value="c"> c) Seoul<br>
        <input type="radio" name="q3" value="d"> d) Bangkok<br>

        <p>4. What is the largest ocean in the world?</p>
        <input type="radio" name="q4" value="a"> a) Atlantic Ocean<br>
        <input type="radio" name="q4" value="b"> b) Indian Ocean<br>
        <input type="radio" name="q4" value="c"> c) Pacific Ocean<br>
        <input type="radio" name="q4" value="d"> d) Arctic Ocean<br>

        <p>5. What is the capital of Australia?</p>
        <input type="radio" name="q5" value="a"> a) Sydney<br>
        <input type="radio" name="q5" value="b"> b) Melbourne<br>
        <input type="radio" name="q5" value="c"> c) Canberra<br>
        <input type="radio" name="q5" value="d"> d) Brisbane<br>

        <p>6. What is the largest mammal in the world?</p>
        <input type="radio" name="q6" value="a"> a) Elephant<br>
        <input type="radio" name="q6" value="b"> b) Blue Whale<br>
        <input type="radio" name="q6" value="c"> c) Giraffe<br>
        <input type="radio" name="q6" value="d"> d) Hippopotamus<br>

        <p>7. What is the largest desert in the world?</p>
        <input type="radio" name="q7" value="a"> a) Sahara Desert<br>
        <input type="radio" name="q7" value="b"> b) Gobi Desert<br>
        <input type="radio" name="q7" value="c"> c) Arabian Desert<br>
        <input type="radio" name="q7" value="d"> d) Kalahari Desert<br>

        <p>8. What is the largest bird in the world?</p>
        <input type="radio" name="q8" value="a"> a) Ostrich<br>
        <input type="radio" name="q8" value="b"> b) Eagle<br>
        <input type="radio" name="q8" value="c"> c) Penguin<br>
        <input type="radio" name="q8" value="d"> d) Albatross<br>

        <p>9. What is the largest country in the world by land area?</p>
        <input type="radio" name="q9" value="a"> a) United States<br>
        <input type="radio" name="q9" value="b"> b) China<br>
        <input type="radio" name="q9" value="c"> c) Russia<br>
        <input type="radio" name="q9" value="d"> d) Canada<br>

        <p>10. What is the largest mountain in the world?</p>
        <input type="radio" name="q10" value="a"> a) Mount Everest<br>
        <input type="radio" name="q10" value="b"> b) K2<br>
        <input type="radio" name="q10" value="c"> c) Kangchenjunga<br>
        <input type="radio" name="q10" value="d"> d) Lhotse<br>

        <br>
        <input type="submit" value="Submit">
    </form>

    <?php
    // Define the correct answers
    $correct_answers = array("a", "c", "a", "c", "c", "b", "a", "a", "c", "a");

    // Initialize the score
    $score = 0;

    // Check if the form was submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Loop through each question
        for ($i = 1; $i <= 10; $i++) {
            // Get the user's answer
            $user_answer = $_POST["q$i"];

            // Check if the user's answer is correct
            if ($user_answer == $correct_answers[$i - 1]) {
                // Increment the score
                $score++;
            }
        }

        // Display the score
        echo "<p>Your score is: $score / 10</p>";
    }
    ?>
</body>
</html>
