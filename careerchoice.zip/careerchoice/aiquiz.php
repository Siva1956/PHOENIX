<!DOCTYPE html>
<html>
<head>
    <title>AI & ML Quiz</title>
</head>
<body bgcolor="moccasin">
    <h1>AI & ML Quiz</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <p>1. What does AI stand for?</p>
        <input type="radio" name="q1" value="a"> a) Artificial Intelligence<br>
        <input type="radio" name="q1" value="b"> b) Automated Intelligence<br>
        <input type="radio" name="q1" value="c"> c) Advanced Intelligence<br>
        <input type="radio" name="q1" value="d"> d) Artificial Information<br>

        <p>2. What is the main goal of machine learning?</p>
        <input type="radio" name="q2" value="a"> a) To make machines intelligent<br>
        <input type="radio" name="q2" value="b"> b) To make machines learn<br>
        <input type="radio" name="q2" value="c"> c) To make machines understand<br>
        <input type="radio" name="q2" value="d"> d) To make machines think<br>

        <p>3. Which of the following is not a type of machine learning?</p>
        <input type="radio" name="q3" value="a"> a) Supervised learning<br>
        <input type="radio" name="q3" value="b"> b) Unsupervised learning<br>
        <input type="radio" name="q3" value="c"> c) Reinforcement learning<br>
        <input type="radio" name="q3" value="d"> d) Semi-supervised learning<br>

        <p>4. What is the main difference between AI and ML?</p>
        <input type="radio" name="q4" value="a"> a) AI is a subset of ML<br>
        <input type="radio" name="q4" value="b"> b) ML is a subset of AI<br>
        <input type="radio" name="q4" value="c"> c) AI and ML are the same thing<br>
        <input type="radio" name="q4" value="d"> d) AI is more advanced than ML<br>

        <p>5. Which of the following is a popular programming language for AI and ML?</p>
        <input type="radio" name="q5" value="a"> a) Java<br>
        <input type="radio" name="q5" value="b"> b) Python<br>
        <input type="radio" name="q5" value="c"> c) C++<br>
        <input type="radio" name="q5" value="d"> d) JavaScript<br>

        <p>6. What is the main purpose of a neural network?</p>
        <input type="radio" name="q6" value="a"> a) To simulate the human brain<br>
        <input type="radio" name="q6" value="b"> b) To make predictions<br>
        <input type="radio" name="q6" value="c"> c) To classify data<br>
        <input type="radio" name="q6" value="d"> d) To optimize algorithms<br>

        <p>7. What is the main advantage of deep learning?</p>
        <input type="radio" name="q7" value="a"> a) It requires less data<br>
        <input type="radio" name="q7" value="b"> b) It can handle unstructured data<br>
        <input type="radio" name="q7" value="c"> c) It can learn from experience<br>
        <input type="radio" name="q7" value="d"> d) It can handle complex problems<br>

        <p>8. What is the main disadvantage of deep learning?</p>
        <input type="radio" name="q8" value="a"> a) It requires a lot of data<br>
        <input type="radio" name="q8" value="b"> b) It can overfit the data<br>
        <input type="radio" name="q8" value="c"> c) It is not scalable<br>
        <input type="radio" name="q8" value="d"> d) It is not accurate<br>

        <p>9. What is the main difference between supervised and unsupervised learning?</p>
        <input type="radio" name="q9" value="a"> a) Supervised learning requires labeled data<br>
        <input type="radio" name="q9" value="b"> b) Unsupervised learning requires labeled data<br>
        <input type="radio" name="q9" value="c"> c) Supervised learning does not require labeled data<br>
        <input type="radio" name="q9" value="d"> d) Unsupervised learning does not require labeled data<br>

        <p>10. What is the main purpose of reinforcement learning?</p>
        <input type="radio" name="q10" value="a"> a) To make predictions<br>
        <input type="radio" name="q10" value="b"> b) To classify data<br>
        <input type="radio" name="q10" value="c"> c) To optimize algorithms<br>
        <input type="radio" name="q10" value="d"> d) To learn from experience<br>

        <br>
        <input type="submit" value="Submit">
    </form>

    <?php
    // Define the correct answers
    $correct_answers = array("a", "b", "d", "b", "b", "a", "d", "b", "a", "d");

    // Initialize the score
    $score = 0;

    // Check if the form was submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Loop through each question
        for ($i = 1; $i <= 10; $i++) {
            // Get the user's answer
            $user_answer = $_POST["q$i"];

            // Check if the user's answer is correct
            if ($user_answer == $correct_answers[$i - 1]) {
                // Increment the score
                $score++;
            }
        }

        // Display the score
        echo "<p>Your score is: $score / 10</p>";

        // Display eligibility message
        if ($score >= 7) {
            echo "<p>You are eligible for the course</p>";
        } else {
            echo "<p>You are not eligible for the course</p>";
        }
    }
    ?>
</body>
</html>
