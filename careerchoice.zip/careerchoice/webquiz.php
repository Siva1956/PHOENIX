<!DOCTYPE html>
<html>
<head>
    <title>Web Developer Quiz</title>
</head>
<body bgcolor="lightblue">
    <h1>Web Developer Quiz</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <p>1. What does HTML stand for?</p>
        <input type="radio" name="q1" value="a"> a) Hyper Text Markup Language<br>
        <input type="radio" name="q1" value="b"> b) Hyperlinks and Text Markup Language<br>
        <input type="radio" name="q1" value="c"> c) Home Tool Markup Language<br>
        <input type="radio" name="q1" value="d"> d) Hyper Text Markup Level<br>

        <p>2. What does CSS stand for?</p>
        <input type="radio" name="q2" value="a"> a) Computer Style Sheets<br>
        <input type="radio" name="q2" value="b"> b) Cascading Style Sheets<br>
        <input type="radio" name="q2" value="c"> c) Creative Style Sheets<br>
        <input type="radio" name="q2" value="d"> d) Colorful Style Sheets<br>

        <p>3. What does PHP stand for?</p>
        <input type="radio" name="q3" value="a"> a) Personal Home Page<br>
        <input type="radio" name="q3" value="b"> b) Hypertext Preprocessor<br>
        <input type="radio" name="q3" value="c"> c) Private Home Page<br>
        <input type="radio" name="q3" value="d"> d) Pretext Hypertext Processor<br>

        <p>4. What does SQL stand for?</p>
        <input type="radio" name="q4" value="a"> a) Structured Query Language<br>
        <input type="radio" name="q4" value="b"> b) Sequential Query Language<br>
        <input type="radio" name="q4" value="c"> c) Structured Question Language<br>
        <input type="radio" name="q4" value="d"> d) Sequential Question Language<br>

        <p>5. What does XML stand for?</p>
        <input type="radio" name="q5" value="a"> a) eXtensible Markup Language<br>
        <input type="radio" name="q5" value="b"> b) eXtensible Multi-purpose Language<br>
        <input type="radio" name="q5" value="c"> c) eXtra Multi-purpose Language<br>
        <input type="radio" name="q5" value="d"> d) eXtra Markup Language<br>

        <p>6. What is the purpose of JavaScript?</p>
        <input type="radio" name="q6" value="a"> a) To style web pages<br>
        <input type="radio" name="q6" value="b"> b) To create dynamic web pages<br>
        <input type="radio" name="q6" value="c"> c) To create static web pages<br>
        <input type="radio" name="q6" value="d"> d) To create web pages<br>

        <p>7. What is the purpose of Bootstrap?</p>
        <input type="radio" name="q7" value="a"> a) To create dynamic web pages<br>
        <input type="radio" name="q7" value="b"> b) To create static web pages<br>
        <input type="radio" name="q7" value="c"> c) To create responsive web pages<br>
        <input type="radio" name="q7" value="d"> d) To create web pages<br>

        <p>8. What is the purpose of jQuery?</p>
        <input type="radio" name="q8" value="a"> a) To create dynamic web pages<br>
        <input type="radio" name="q8" value="b"> b) To create static web pages<br>
        <input type="radio" name="q8" value="c"> c) To create responsive web pages<br>
        <input type="radio" name="q8" value="d"> d) To create web pages<br>

        <p>9. What is the purpose of AJAX?</p>
        <input type="radio" name="q9" value="a"> a) To create dynamic web pages<br>
        <input type="radio" name="q9" value="b"> b) To create static web pages<br>
        <input type="radio" name="q9" value="c"> c) To create responsive web pages<br>
        <input type="radio" name="q9" value="d"> d) To create web pages<br>

        <p>10. What is the purpose of JSON?</p>
        <input type="radio" name="q10" value="a"> a) To create dynamic web pages<br>
        <input type="radio" name="q10" value="b"> b) To create static web pages<br>
        <input type="radio" name="q10" value="c"> c) To create responsive web pages<br>
        <input type="radio" name="q10" value="d"> d) To create web pages<br>

        <br>
        <input type="submit" value="Submit">
    </form>

    <?php
    // Define the correct answers
    $correct_answers = array("a", "b", "b", "a", "a", "b", "c", "a", "a", "d");

    // Initialize the score
    $score = 0;

    // Check if the form was submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Loop through each question
        for ($i = 1; $i <= 10; $i++) {
            // Get the user's answer
            $user_answer = $_POST["q$i"];

            // Check if the user's answer is correct
            if ($user_answer == $correct_answers[$i - 1]) {
                // Increment the score
                $score++;
            }
        }

        // Display the score
        echo "<p>Your score is: $score / 10</p>";

        // Display eligibility message
        if ($score >= 7) {
            echo "<p>You are eligible</p>";
        } else {
            echo "<p>You are not eligible</p>";
        }
    }
    ?>
</body>
</html>
