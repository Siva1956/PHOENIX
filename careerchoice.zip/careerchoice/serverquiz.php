<!DOCTYPE html>
<html>
<head>
    <title>Server Computing Quiz</title>
</head>
<body bgcolor="lightpink">
    <h1>Server Computing Quiz</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <p>1. What is a server?</p>
        <input type="radio" name="q1" value="a"> a) A computer program that provides services to other computer programs<br>
        <input type="radio" name="q1" value="b"> b) A computer program that provides services to users<br>
        <input type="radio" name="q1" value="c"> c) A computer program that provides services to itself<br>
        <input type="radio" name="q1" value="d"> d) A computer program that provides services to the internet<br>

        <p>2. What is a server operating system?</p>
        <input type="radio" name="q2" value="a"> a) An operating system that runs on a server<br>
        <input type="radio" name="q2" value="b"> b) An operating system that provides services to other operating systems<br>
        <input type="radio" name="q2" value="c"> c) An operating system that provides services to users<br>
        <input type="radio" name="q2" value="d"> d) An operating system that provides services to the internet<br>

        <p>3. What is a web server?</p>
        <input type="radio" name="q3" value="a"> a) A server that hosts websites<br>
        <input type="radio" name="q3" value="b"> b) A server that provides web services<br>
        <input type="radio" name="q3" value="c"> c) A server that provides services to the internet<br>
        <input type="radio" name="q3" value="d"> d) A server that provides services to other servers<br>

        <p>4. What is a database server?</p>
        <input type="radio" name="q4" value="a"> a) A server that hosts databases<br>
        <input type="radio" name="q4" value="b"> b) A server that provides database services<br>
        <input type="radio" name="q4" value="c"> c) A server that provides services to the internet<br>
        <input type="radio" name="q4" value="d"> d) A server that provides services to other servers<br>

        <p>5. What is a file server?</p>
        <input type="radio" name="q5" value="a"> a) A server that hosts files<br>
        <input type="radio" name="q5" value="b"> b) A server that provides file services<br>
        <input type="radio" name="q5" value="c"> c) A server that provides services to the internet<br>
        <input type="radio" name="q5" value="d"> d) A server that provides services to other servers<br>

        <p>6. What is a print server?</p>
        <input type="radio" name="q6" value="a"> a) A server that hosts printers<br>
        <input type="radio" name="q6" value="b"> b) A server that provides print services<br>
        <input type="radio" name="q6" value="c"> c) A server that provides services to the internet<br>
        <input type="radio" name="q6" value="d"> d) A server that provides services to other servers<br>

        <p>7. What is a mail server?</p>
        <input type="radio" name="q7" value="a"> a) A server that hosts mailboxes<br>
        <input type="radio" name="q7" value="b"> b) A server that provides mail services<br>
        <input type="radio" name="q7" value="c"> c) A server that provides services to the internet<br>
        <input type="radio" name="q7" value="d"> d) A server that provides services to other servers<br>

        <p>8. What is a proxy server?</p>
        <input type="radio" name="q8" value="a"> a) A server that hosts proxies<br>
        <input type="radio" name="q8" value="b"> b) A server that provides proxy services<br>
        <input type="radio" name="q8" value="c"> c) A server that provides services to the internet<br>
        <input type="radio" name="q8" value="d"> d) A server that provides services to other servers<br>

        <p>9. What is a DNS server?</p>
        <input type="radio" name="q9" value="a"> a) A server that hosts domain names<br>
        <input type="radio" name="q9" value="b"> b) A server that provides DNS services<br>
        <input type="radio" name="q9" value="c"> c) A server that provides services to the internet<br>
        <input type="radio" name="q9" value="d"> d) A server that provides services to other servers<br>

        <p>10. What is a DHCP server?</p>
        <input type="radio" name="q10" value="a"> a) A server that hosts DHCP<br>
        <input type="radio" name="q10" value="b"> b) A server that provides DHCP services<br>
        <input type="radio" name="q10" value="c"> c) A server that provides services to the internet<br>
        <input type="radio" name="q10" value="d"> d) A server that provides services to other servers<br>

        <br>
        <input type="submit" value="Submit">
    </form>

    <?php
    // Define the correct answers
    $correct_answers = array("a", "a", "a", "a", "a", "a", "a", "a", "b", "b");

    // Initialize the score
    $score = 0;

    // Check if the form was submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Loop through each question
        for ($i = 1; $i <= 10; $i++) {
            // Get the user's answer
            $user_answer = $_POST["q$i"];

            // Check if the user's answer is correct
            if ($user_answer == $correct_answers[$i - 1]) {
                // Increment the score
                $score++;
            }
        }

        // Display the score
        echo "<p>Your score is: $score / 10</p>";

        // Display eligibility message
        if ($score >= 7) {
            echo "<p>You are eligible</p>";
        } else {
            echo "<p>You are not eligible</p>";
        }
    }
    ?>
</body>
</html>
